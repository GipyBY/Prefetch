#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <winternl.h>
#include <MinHook.h>
#include <iostream>
#include <string>
#define STATUS_ACCESS_DENIED ((NTSTATUS)0xC0000022L)
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "../Lib/libMinHook.x64.lib")
#include <filesystem>


typedef NTSTATUS(NTAPI* fnNtCreateFile)(
    PHANDLE FileHandle,
    ACCESS_MASK DesiredAccess,
    POBJECT_ATTRIBUTES ObjectAttributes,
    PIO_STATUS_BLOCK IoStatusBlock,
    PLARGE_INTEGER AllocationSize,
    ULONG FileAttributes,
    ULONG ShareAccess,
    ULONG CreateDisposition,
    ULONG CreateOptions,
    PVOID EaBuffer,
    ULONG EaLength
    );

fnNtCreateFile OriginalNtCreateFile = nullptr;


bool prefetch(const UNICODE_STRING* FileName) {
    if (!FileName || !FileName->Buffer) return false;

    std::wstring fullPath(FileName->Buffer, FileName->Length / sizeof(WCHAR));
    std::wstring fileName;

    try {
        fileName = std::filesystem::path(fullPath).filename().wstring();
    }
    catch (...) {
        fileName = fullPath;
    }

    for (auto& c : fileName) c = towlower(c);

    if (fileName.length() < 3) return false;
    if (fileName.compare(fileName.length() - 3, 3, L".pf") != 0) return false;

    return fileName.find(L"prefetchname") != std::wstring::npos;
}


NTSTATUS NTAPI HookedNtCreateFile(
    PHANDLE FileHandle,
    ACCESS_MASK DesiredAccess,
    POBJECT_ATTRIBUTES ObjectAttributes,
    PIO_STATUS_BLOCK IoStatusBlock,
    PLARGE_INTEGER AllocationSize,
    ULONG FileAttributes,
    ULONG ShareAccess,
    ULONG CreateDisposition,
    ULONG CreateOptions,
    PVOID EaBuffer,
    ULONG EaLength
) {
    if (ObjectAttributes && ObjectAttributes->ObjectName && prefetch(ObjectAttributes->ObjectName)) {
        return STATUS_ACCESS_DENIED;
    }

    return OriginalNtCreateFile(
        FileHandle, DesiredAccess, ObjectAttributes, IoStatusBlock,
        AllocationSize, FileAttributes, ShareAccess,
        CreateDisposition, CreateOptions, EaBuffer, EaLength);
}

void InitializeHook() {
    if (MH_Initialize() != MH_OK) return;

    HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
    if (!hNtdll) return;

    void* pNtCreateFile = GetProcAddress(hNtdll, "NtCreateFile");
    if (!pNtCreateFile) return;

    if (MH_CreateHook(pNtCreateFile, HookedNtCreateFile, reinterpret_cast<LPVOID*>(&OriginalNtCreateFile)) != MH_OK) return;

    MH_EnableHook(pNtCreateFile);
}

DWORD WINAPI ConsoleThread(LPVOID lpParam) {
    AllocConsole();
    freopen("CONOUT$", "w", stdout);

    std::cout << "press ctrl + L for exit" << std::endl;

    while (true) {
        if (GetAsyncKeyState(VK_CONTROL) & 0x8000 && GetAsyncKeyState('L') & 0x8000) {
            break;
        }
        Sleep(100);
    }

    FreeConsole();
    FreeLibraryAndExitThread((HMODULE)lpParam, 0);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        InitializeHook();
        CreateThread(NULL, 0, ConsoleThread, hModule, 0, NULL);
    }
    return TRUE;
}
